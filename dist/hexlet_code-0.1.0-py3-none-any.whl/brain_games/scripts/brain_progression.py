#!/usr/bin/env python3

def start_progression():
    from brain_games.game_seq import procedure
    procedure(4)


def main():
    start_progression()


if __name__ == '__main__':
    main()
