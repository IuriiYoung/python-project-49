#!/usr/bin/env python3

def start_prime():
    from brain_games.game_seq import procedure
    procedure(5)


def main():
    start_prime()


if __name__ == '__main__':
    main()
