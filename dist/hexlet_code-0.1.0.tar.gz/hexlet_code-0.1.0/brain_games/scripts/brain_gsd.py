#!/usr/bin/env python3

def start_gsd():
    from brain_games.game_seq import procedure
    procedure(3)


def main():
    start_gsd()


if __name__ == '__main__':
    main()
