#!/usr/bin/env python3

from brain_games.body_even import gen_number_answer


def run_brain_even():
    gen_number_answer()


def main():
    run_brain_even()


if __name__ == '__main__':
    main()
