#!/usr/bin/env python3

def start_even():
    from brain_games.game_seq import procedure
    procedure(2)


def main():
    start_even()


if __name__ == '__main__':
    main()
